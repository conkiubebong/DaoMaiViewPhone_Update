#!/usr/bin/env sh
# Chạy DaoMaiView: .so FFmpeg và daomai-adb/adb nằm cạnh file này.
cd "$(dirname "$0")"
chmod +x DaoMaiView daomai-adb/adb 2>/dev/null
exec ./DaoMaiView "$@"
