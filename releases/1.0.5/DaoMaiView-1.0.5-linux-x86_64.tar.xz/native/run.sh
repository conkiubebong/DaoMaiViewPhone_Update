#!/usr/bin/env sh
# Chạy DaoMaiView: .so FFmpeg và daomai-adb/adb nằm cạnh file này (binary đã có RPATH $ORIGIN; LD_LIBRARY_PATH chỉ để chắc).
cd "$(dirname "$0")"
chmod +x DaoMaiView daomai-adb/adb 2>/dev/null
LD_LIBRARY_PATH="$PWD${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" exec ./DaoMaiView "$@"
